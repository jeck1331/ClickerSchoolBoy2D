﻿using _Scripts.Helpers;
using _Scripts.Models.Upgrade;
using TMPro;
using UnityEngine;

namespace _Scripts.Prefabs
{
    public class UpgradeIncomePrefab : UpgradeBaseItem<UpgradeIncomeField, ShopManager>
    {
        [SerializeField] private UIntValue incomeValue;
        [SerializeField] private ObserverSO incomeObserver;

        [SerializeField] private TMP_Text incomeText;

        public override void Initialize(UpgradeIncomeField data, UpgradeStateItem stateItem, UpgradeStateItem previousStateItem, ShopManager shopManager)
        {
            _data = data;
            state = stateItem;
            previousState = previousStateItem;
            manager = shopManager;

            titleText.text = data.Title;
            RefreshPurchaseState();
            scoreObserver.OnValueChanged += UpdateStateButton;
            incomeObserver.OnValueChanged += RefreshPurchaseState;
        }

        protected override void UpdateStateButton()
        {
            _button.interactable = UpgradeEconomyService.CanBuyIncomeUpgrade(_data, state, scoreValue.Value);
        }

        private void RefreshPurchaseState()
        {
            if (state.IsSecret)
                UpgradeEconomyService.TryUnlockByPreviousId(state, previousState);

            UpdateStateTexts();
            UpdateStateButton();
        }

        private void UpdateStateTexts()
        {
            bool isSecret = state.IsSecret;
            long? price = _data.GetPrice(state.Count);

            _image.material = isSecret ? matSecretField : null;
            priceText.text = isSecret ? "???" : price?.ScoreViewFromNumber() ?? "MAX";
            incomeText.text = isSecret ? "???" : $"+{UIntValue.ToCoins(_data.Income):0.#}/s";
            descriptionText.text = isSecret ? string.Empty : $"{_data.Description}  Owned {state.Count}";
        }

        // private void OnDestroy()
        // {
        //     Debug.Log($"INCOME {name}: Открепил событие к scoreObserver");
        //     scoreObserver.OnValueChanged -= UpdateStateButton;
        // }

        private void OnDisable()
        {
            scoreObserver.OnValueChanged -= UpdateStateButton;
            incomeObserver.OnValueChanged -= RefreshPurchaseState;
        }

        public override void OnBuyEvent()
        {
            if (UpgradeEconomyService.TryBuyIncomeUpgrade(_data, state, scoreValue, incomeValue, manager))
                AudioManager.Instance?.PlaySfx(SfxType.UpgradeBuy);
        }
    }
}