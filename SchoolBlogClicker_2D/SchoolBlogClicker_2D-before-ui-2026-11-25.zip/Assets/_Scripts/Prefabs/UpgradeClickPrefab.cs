using _Scripts.Core;
using _Scripts.Models.Upgrade;
using _Scripts.Models.Enums;
using TMPro;
using UnityEngine;

namespace _Scripts.Prefabs
{
    public class UpgradeClickPrefab : UpgradeBaseItem<UpgradeClickField, UpgradeManager>
    {
        [SerializeField] private UIntValue powerValue;
        [SerializeField] private ObserverSO powerObserver;

        [SerializeField] private TMP_Text powerText;

        public override void Initialize(UpgradeClickField data, UpgradeStateItem stateItem, UpgradeStateItem previousStateItem, UpgradeManager upgradeManager)
        {
            _data = data;
            state = stateItem;
            previousState = previousStateItem;
            manager = upgradeManager;

            titleText.text = data.Title;
            RefreshPurchaseState();
            scoreObserver.OnValueChanged += UpdateStateButton;
            powerObserver.OnValueChanged += RefreshPurchaseState;
        }


        protected override void UpdateStateButton()
        {
            _button.interactable = UpgradeEconomyService.CanBuyClickUpgrade(_data, state, scoreValue.Value);
        }

        private void RefreshPurchaseState()
        {
            if (state.IsSecret)
                UpgradeEconomyService.TryUnlockByPreviousId(state, previousState);

            UpdateStateTexts();
            UpdateStateButton();
        }

        private void UpdateStateTexts()
        {
            bool isSecret = state.IsSecret;
            _image.material = isSecret ? matSecretField : null;
            priceText.text = isSecret ? "???" : _data.Price.ToString();
            powerText.text = isSecret ? "???" : _data.CalcType switch
            {
                ClickCalcType.Add => $"+{UIntValue.ToCoins(_data.Power):0.##}",
                ClickCalcType.Multiply => $"x{_data.Power}",
                _ => $"{UIntValue.ToCoins(CalcCacheHelper.StartingPower + _data.Power):0.##}"
            };
            descriptionText.text = isSecret ? string.Empty : _data.Description;
        }

        // private void OnDestroy()
        // {
        //     Debug.Log($"{name}: Открепил события");
        //     scoreObserver.OnValueChanged -= UpdateStateButton;
        //     powerObserver.OnValueChanged -= UpdateStateButton;
        // }
        private void OnDisable()
        {
            // Debug.Log($"CLICK {name}: Откерпил события");
            scoreObserver.OnValueChanged -= UpdateStateButton;
            powerObserver.OnValueChanged -= RefreshPurchaseState;
        }

        public override void OnBuyEvent()
        {
            if (!UpgradeEconomyService.TryBuyClickUpgrade(_data, state, scoreValue, powerValue, manager))
                return;

            gameObject.SetActive(false);
            AudioManager.Instance?.PlaySfx(SfxType.UpgradeBuy);
        }
    }
}